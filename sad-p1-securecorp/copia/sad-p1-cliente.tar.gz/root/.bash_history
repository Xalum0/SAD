# CLIENTE: buscar las entradas de A3
ldapsearch -x -LLL -H ldap://ldap.securecorp.local   -b "dc=securecorp,dc=local"   "(|(uid=acolon)(uid=mtorres)(cn=rrhh)(cn=sistemas))" dn
cd /ldif/
# CLIENTE
ldapadd -x -H ldap://ldap.securecorp.local   -D "cn=admin,dc=securecorp,dc=local" -W -f 01-ejemplo.ldif
ldapadd -x -H ldap://ldap.securecorp.local   -D "cn=admin,dc=securecorp,dc=local" -W -f 02-tu-turno.ldif
ldapsearch -x -LLL -H ldap://ldap.securecorp.local   -b "dc=securecorp,dc=local"   "(|(uid=acolon)(uid=mtorres)(cn=rrhh)(cn=sistemas))" dn
exit
ldappasswd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -s 'Lucia2026' "uid=lromero,ou=people,dc=securecorp,dc=local"
ldappasswd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -s 'Andres2026' "uid=acolon,ou=people,dc=securecorp,dc=local"
ldappasswd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -s 'Marta2026' "uid=mtorres,ou=people,dc=securecorp,dc=local"
exit
nano /etc/ldap/ldap.conf
ldapwhoami -x -H ldaps://ldap.securecorp.local -D "uid=lromero,ou=people,dc=securecorp,dc=local" -w 'Lucia2026'
exit
kinit lromero        # te pide su contraseña
klist                # su pulsera: krbtgt/SECURECORP.LOCAL@SECURECORP.LOCAl 
kinit lromero        # te pide su contraseña
exit
kinit lromero        # te pide su contraseña
kinit lromero        # te pide su contraseña
clear
kinit acolon
klist
kvno host/web.securecorp.local
klist
kinit acolon
klist
kvno host/web.securecorp.local
klist
kdestroy
exit
kdestroy
kinit mtorres
exit
exit
ldapsearch -x -LLL -H ldap://ldap.securecorp.local   -b "dc=securecorp,dc=local"   "(|(uid=acolon)(uid=mtorres)(cn=rrhh)(cn=sistemas))" dn
ldapsearch -x -LLL -H ldap://ldap.securecorp.local   -b "dc=securecorp,dc=local"   "((uid=acolon)(uid=mtorres)(cn=rrhh)(cn=sistemas))" dn
ldapsearch -x -LLL -H ldap://ldap.securecorp.local   -b "dc=securecorp,dc=local"   "(|(uid=acolon)(uid=mtorres)(cn=rrhh)(cn=sistemas))" dn
ldapadd -x -H ldap://ldap.securecorp.local   -D "cn=admin,dc=securecorp,dc=local" -W -f 01-ejemplo.ldif
exit
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local   -b "dc=securecorp,dc=local"   "(|(uid=acolon)(uid=mtorres)(cn=rrhh)(cn=sistemas))" dn
cat /etc/ldap/ldap.conf 
cat /etc/ldap/slapd.d/
cat /etc/ldap/slapd.d/cn\=config
cat /etc/ldap/slapd.d/cn\=config.ldif 
exit
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local   -b "dc=securecorp,dc=local"   "(|(uid=acolon)(uid=mtorres)(cn=rrhh)(cn=sistemas))" dn
nano /ldif/02-tu-turno.ldif 
ldapadd -x -H ldap://ldap.securecorp.local   -D "cn=admin,dc=securecorp,dc=local" -W -f 02-tu-turno.ldif
ldapadd -x -H ldap://ldap.securecorp.local   -D "cn=admin,dc=securecorp,dc=local" -W -f /ldif/02-tu-turno.ldif
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local   -b "dc=securecorp,dc=local"   "(|(uid=acolon)(uid=mtorres)(cn=rrhh)(cn=sistemas))" dn
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local   -b "dc=securecorp,dc=local"   "(|(uid=acolon)(uid=nvegas)(cn=rrhh)(cn=sistemas))" dn
clear
ldapadd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f /ldif/02-tu-turno.ldif 
ldapadd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f /ldif/01-ejemplo.ldif 
ldapadd -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f /ldif/02-tu-turno.ldif 
ldapadd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f /ldif/01-ejemplo.ldif 
ldapadd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f /ldif/01-ejemplo.ldif 
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local   -b "dc=securecorp,dc=local"   "(|(uid=acolon)(uid=nvegas)(cn=rrhh)(cn=sistemas))" dn
nano /ldif/02-tu-turno.ldif 
ldapadd -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f /ldif/02-tu-turno.ldif 
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local   -b "dc=securecorp,dc=local"   "(|(uid=acolon)(uid=nvegas)(cn=sistemas))" dn
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local   -b "dc=securecorp,dc=local"   "(|(uid=nvegas))" dn
cd /ldif/
clear
ldapwhoami -x -H ldaps://ldap.securecorp.local -D "uid=nvegas,ou=people,dc=securecorp,dc=local"
ldappasswd -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W   -s 'Nuria2026' "uid=nvegas,ou=people,dc=securecorp,dc=local"
exit
ldapadd -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f /ldif/02-tu-turno.ldif 
ldapadd -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f /ldif/02-tu-turno.ldif 
cd /ldif
nano 04-defensa.ldif
ldapadd -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 04-defensa.ldif 
ldappasswd -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W   -s 'Nuria2026' "uid=nvegas,ou=people,dc=securecorp,dc=local"
ldapwhoami -x -H ldaps://ldap.securecorp.local -D "uid=nvegas,ou=people,dc=securecorp,dc=local"
ldappasswd -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W   -s 'Nuria2026' "uid=nvegas,ou=people,dc=securecorp,dc=local"
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local   -b "dc=securecorp,dc=local"   "(|(uid=nvegas))" dn
ldapwhoami -x -H ldaps://ldap.securecorp.local -D "uid=nvegas,ou=people,dc=securecorp,dc=local"
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local   -b "dc=securecorp,dc=local"   "(|(uid=nvegas))" dn
ldappasswd -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W   -s 'Nuria2026' "uid=nvegas,ou=people,dc=securecorp,dc=local"
ldapwhoami -x -H ldaps://ldap.securecorp.local -D "uid=nvegas,ou=people,dc=securecorp,dc=local"
ldappasswd -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -s 'Nuria2026' "uid=nvegas,ou=people,dc=securecorp,dc=local"
ldappasswd -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -s 'Nuria2026' "uid=nvegas,ou=people,dc=securecorp,dc=local"
ldapwhoami -x -H ldaps://ldap.securecorp.local -D "uid=nvegas,ou=people,dc=securecorp,dc=local"
ldapwhoami -x -H ldaps://ldap.securecorp.local -D "uid=nvegas,ou=people,dc=securecorp,dc=local"
clear
exit
ldapwhoami -x -H ldaps://ldap.securecorp.local -D "uid=nvegas,ou=people,dc=securecorp,dc=local"
ldappasswd -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W   -s 'Nuria2026' "uid=nvegas,ou=people,dc=securecorp,dc=local"
ldapwhoami -x -H ldaps://ldap.securecorp.local -D "uid=nvegas,ou=people,dc=securecorp,dc=local"
cd /ldif/
ldapadd -c -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 04-defensa.ldif 
clear
ldappasswd -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W   -s 'Nuria2026' "uid=nvegas,ou=people,dc=securecorp,dc=local"
ldapwhoami -x -H ldaps://ldap.securecorp.local -D "uid=nvegas,ou=people,dc=securecorp,dc=local"
ldapwhoami -d 1 -x -H ldaps://ldap.securecorp.local -D "uid=Nvegas,ou=people,dc=securecorp,dc=local" -w 'Nuria2026' 2>&1 | grep TLS
ldapwhoami -x -H ldaps://ldap.securecorp.local -D "uid=nvegas,ou=people,dc=securecorp,dc=local"
cat /etc/ldap/ldap.conf 
ldapwhoami -x -H ldaps://ldap.securecorp.local -D "uid=nvegas,ou=people,dc=securecorp,dc=local"
ldappasswd -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -s 'Nuria2026' "uid=nvegas,ou=people,dc=securecorp,dc=local"
ldapwhoami -x -H ldaps://ldap.securecorp.local -D "uid=nvegas,ou=people,dc=securecorp,dc=local"
ldappasswd -x -H ldap://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -s 'Nuria2026' "uid=nvegas,ou=people,dc=securecorp,dc=local"
ldapwhoami -x -H ldaps://ldap.securecorp.local -D "uid=nvegas,ou=people,dc=securecorp,dc=local"
ldapwhoami -x -H ldap://ldap.securecorp.local -D "uid=nvegas,ou=people,dc=securecorp,dc=local"
clear
ldapadd -c -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 04-defensa.ldif 
ldapadd -c -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -f 04-defensa.ldif 
ldappasswd -x -H ldaps://ldap.securecorp.local -D "cn=admin,dc=securecorp,dc=local" -W -s 'Nuria2026' "uid=nvegas,ou=people,dc=securecorp,dc=local"
ldapwhoami -x -H ldaps://ldap.securecorp.local -D "uid=nvegas,ou=people,dc=securecorp,dc=local"
ldapsearch -x -LLL -H ldaps://ldap.securecorp.local   -b "dc=securecorp,dc=local"   "(|(uid=nvegas))" dn
help ldapwhoami 
ldapwhoami -help
ldapwhoami -x -H ldaps://ldap.securecorp.local -D "uid=nvegas,ou=people,dc=securecorp,dc=local" -w 'Nuria2026'
exit
