mkdir -p /etc/ldap/tls
cp /pki/ca/ca.crt /pki/servidor/ldap.crt /pki/servidor/ldap.key /etc/ldap/tls/
ldapmodify -Y EXTERNAL -H ldapi:/// -f /ldif/03-tls.ldif     # → modifying entry "cn=config"
nano /etc/default/slapd
exit
mkdir -p /etc/ldap/tls
cp /pki/ca/ca.crt /pki/servidor/ldap.crt /pki/servidor/ldap.key /etc/ldap/tls/
chown -R openldap:openldap /etc/ldap/tls
chmod 600 /etc/ldap/tls/ldap.key
ls -l /etc/ldap/tls
exit
ldapmodify -Y EXTERNAL -H ldapi:/// -f /ldif/03-tls.ldif     
cat /ldif/03-tls.ldif
nano /ldif/03-tls.ldif
ldapmodify -Y EXTERNAL -H ldapi:/// -f /ldif/03-tls.ldif     
kdb5_util create -s -r SECURECORP.LOCAL     # te pide una "master key": invéntala y apúntala
service krb5-kdc start
[200~kadmin.local -q "addprinc lromero"
kadmin.local -q "addprinc -randkey host/web.securecorp.local"
kadmin.local -q "addprinc acolon"
kadmin.local -q "addprinc lromero"
kadmin.local -q "addprinc -randkey host/web.securecorp.local"
kadmin.local -q "addprinc acolon"
kadmin.local -q "addprinc acolon"
kadmin.local -q "addprinc lromero"
kadmin.local -q "addprinc lromero"
clear
kadmin.local -q "addprinc mtorres"
exit
kadmin.local -q "addprinc lromero"
kadmin.local -q "addprinc -randkey host/web.securecorp.local"
kadmin.local -q "addprinc acolon"
kadmin.local -q "addprinc mtorres"
kadmin.local -q "listprincs"
exit
exit
kadmin.local -q "modprinc -allow_tix mtorres"
kadmin.local -q "getprinc mtorres"
exit
kadmin.local -q "modprinc -allow_tix mtorres"
kadmin.local -q "getprinc mtorres"
kadmin.local -q "listprincs"
exit
openssl x509 -in /pki/ca/ca.crt -noout -subject -issuer -dates
clear
openssl x509 -in /pki/ca/ca.crt -noout -subject -issuer -dates
exit
exit
clear
cat /etc/ldap/tls/ca.crt 

cat /etc/ldap/tls/ldap.key 
cat /etc/default/slapd 
more /etc/default/slapd 
clear
exit
nano /ldif/
nano /ldif/02-tu-turno.ldif 
ldapadd -x -H ldap://ldap.securecorp.local   -D "cn=admin,dc=securecorp,dc=local" -W -f /ldif/02-tu-turno.ldif
ldap
clear
ldap status
clear
ldapadd -x -H ldap://ldap.securecorp.local   -D "cn=admin,dc=securecorp,dc=local" -W -f /ldif/02-tu-turno.ldif
clear
ldapadd -x -H ldap://ldap.securecorp.local   -D "cn=admin,dc=securecorp,dc=local" -W -f /ldif/02-tu-turno.ldif
exit
nano /etc/default/slapd
exit
