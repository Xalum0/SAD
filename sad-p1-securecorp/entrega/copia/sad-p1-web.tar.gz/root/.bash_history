exit
exit
exit
kinit acolon
kinit acolon
exit
exit
kinit lromero
kinit lromero
kinit lromero
kinit lromero
kinit lromero
exit
klist
exit
